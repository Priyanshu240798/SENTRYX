# SENTRY — SMS Spam Detector

A static HTML/CSS/JavaScript demo for classifying sample SMS messages.

## Run locally
Open `index.html` in a browser, or use the VS Code Live Server extension.

## Deploy
This is a static website. Import this repository into Vercel with the framework preset set to **Other**. No build command or output directory is required when `index.html` is in the repository root.

## Important implementation note
The current uploaded page uses a JavaScript suspicious-keyword scoring heuristic and a sample-message list. It does not contain a trained Python/Naive Bayes model or an ML backend, so the displayed algorithm/accuracy claims should not be presented as verified machine-learning results.
